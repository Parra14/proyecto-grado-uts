import { Component, OnInit } from '@angular/core';
import { TasksService } from "../../services/tasks.service";
import { Tasks } from "../../models/tasks";

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {

  tasks: Tasks[]=[];

  constructor(private tasksService: TasksService) { }



  ngOnInit(): void {
    this.tasksService.getTasks()
    .subscribe(
      res => {
        console.log(res);
        this.tasks = res;
      },
      err => console.log(err)
    )
  }



}
